import React, { useEffect, useState } from 'react'
import jwt from 'jsonwebtoken'
import { useHistory } from 'react-router-dom'

const Dashboard = () => {
	const history = useHistory()
	const [topic, setTopic] = useState('')
	const [tempTopic, setTempTopic] = useState('')

	async function populateTopic() {
		const req = await fetch('http://localhost:3000/api/topic', {
			headers: {
				'x-access-token': localStorage.getItem('token'),
			},
		})

		const data = await req.json()
		if (data.status === 'ok') {
			setTopic(data.topic)
		} else {
			alert(data.error)
		}
	}

	useEffect(() => {
		const token = localStorage.getItem('token')
		if (token) {
			const user = jwt.decode(token)
			if (!user) {
				localStorage.removeItem('token')
				history.replace('/login')
			} else {
				populateTopic()
			}
		}
	}, [])

	async function updateTopic(event) {
		event.preventDefault()

		const req = await fetch('http://localhost:3000/api/topic', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'x-access-token': localStorage.getItem('token'),
			},
			body: JSON.stringify({
				topic: tempTopic,
			}),
		})

		const data = await req.json()
		if (data.status === 'ok') {
			setTopic(tempTopic)
			setTempTopic('')
		} else {
			alert(data.error)
		}
	}

	return (
		<center>
		<div className="GeeksForGeeks">
			<h1>Product: {topic || 'No product found'}</h1>
			<form onSubmit={updateTopic}>
				<input
					type="text"
					placeholder="Product Name"
					value={tempTopic}
					onChange={(e) => setTempTopic(e.target.value)}
				/>
				<input
					type="number"
					placeholder="Vat"
				
				/>
				<input
					type="number"
					placeholder="Quantity"
				
				/>
				<input
					type="number"
					placeholder="Price(net)"
					
				/>
				<input
					type="number"
					placeholder="Price(gross)"
					
				/>
				
				<input type="submit" value="Update topic" />
			</form>
		</div>
		</center>
	)
}

export default Dashboard
